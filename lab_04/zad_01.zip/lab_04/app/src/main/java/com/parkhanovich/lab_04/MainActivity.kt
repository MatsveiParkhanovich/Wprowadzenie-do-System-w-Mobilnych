
package com.parkhanovich.lab_04

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.parkhanovich.lab_04.models.CodeManager

class MainActivity : AppCompatActivity() {

    private lateinit var cm: CodeManager

    private lateinit var editTextName: EditText
    private lateinit var textViewCounter: TextView
    private lateinit var textViewMotivation: TextView
    private lateinit var buttonIncrease: Button
    private lateinit var buttonClean: Button
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(
                systemBars.left,
                systemBars.top,
                systemBars.right,
                systemBars.bottom
            )
            insets
        }

        // Create CodeManager object
        cm = CodeManager()

        // Connect interface elements
        editTextName = findViewById(R.id.editTextName)
        textViewCounter = findViewById(R.id.textViewCounter)
        textViewMotivation = findViewById(R.id.textViewMotivation)
        buttonIncrease = findViewById(R.id.buttonIncrease)
        buttonClean = findViewById(R.id.buttonClean)
        progressBar = findViewById(R.id.progressBar)

        // Increase counter
        buttonIncrease.setOnClickListener {
            cm.name = editTextName.text.toString()
            cm.increaseCounter()
            updateInterface()
        }

        // Clean counter
        buttonClean.setOnClickListener {
            cm.cleanCounter()
            updateInterface()
        }

        updateInterface()
    }

    private fun updateInterface() {
        textViewCounter.text = "Lines of code: ${cm.counter}"

        val motivation = when (cm.counter) {
            0 -> "Start writing code!"
            in 1..10 -> "Good start! Keep going!"
            in 11..30 -> "Great job! You are improving!"
            in 31..50 -> "Excellent work! Keep coding!"
            else -> "Amazing! You are a coding master!"
        }

        val name = cm.name.ifBlank { "Programmer" }

        textViewMotivation.text =
            "Congratulations, $name! You have written ${cm.counter} lines of code!\n$motivation"

        progressBar.progress = cm.counter.coerceAtMost(100)
    }
}


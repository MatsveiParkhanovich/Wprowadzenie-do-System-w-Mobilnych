package com.parkhanovich.lab_04.models

class CodeManager {

    var name: String = ""
    var counter: Int = 0

    fun increaseCounter() {
        counter++
    }

    fun cleanCounter() {
        counter = 0
    }
}
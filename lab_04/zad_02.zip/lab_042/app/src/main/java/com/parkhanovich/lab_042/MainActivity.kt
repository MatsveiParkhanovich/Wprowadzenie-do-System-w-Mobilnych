
package com.parkhanovich.lab_042

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val buttonklik = findViewById<Button>(R.id.klik)
        val maxnum = findViewById<EditText>(R.id.maxnum)

        var randlimit = 0

        maxnum.addTextChangedListener {
            randlimit = maxnum.text.toString().toIntOrNull() ?: 0
        }

        buttonklik.setOnClickListener {
            if (randlimit > 0) {
                val numran = Random.nextInt(1, randlimit + 1)
                buttonklik.text = numran.toString()
            } else {
                maxnum.error = "Enter a number greater than 0"
            }
        }
    }
}

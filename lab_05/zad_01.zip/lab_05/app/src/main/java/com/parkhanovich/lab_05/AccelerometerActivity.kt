
package com.parkhanovich.lab_05

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class AccelerometerActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null

    private lateinit var rawX: TextView
    private lateinit var rawY: TextView
    private lateinit var rawZ: TextView

    private lateinit var lowX: TextView
    private lateinit var lowY: TextView
    private lateinit var lowZ: TextView

    private lateinit var highX: TextView
    private lateinit var highY: TextView
    private lateinit var highZ: TextView

    private val alpha = 0.8f

    private val gravity = FloatArray(3)
    private val acceleration = FloatArray(3)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_accelerometer)

        rawX = findViewById(R.id.rawX)
        rawY = findViewById(R.id.rawY)
        rawZ = findViewById(R.id.rawZ)

        lowX = findViewById(R.id.lowX)
        lowY = findViewById(R.id.lowY)
        lowZ = findViewById(R.id.lowZ)

        highX = findViewById(R.id.highX)
        highY = findViewById(R.id.highY)
        highZ = findViewById(R.id.highZ)

        sensorManager =
            getSystemService(Context.SENSOR_SERVICE) as SensorManager

        accelerometer =
            sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    }

    override fun onResume() {
        super.onResume()

        accelerometer?.let {
            sensorManager.registerListener(
                this,
                it,
                SensorManager.SENSOR_DELAY_UI
            )
        }
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    private fun lowPass(current: Float, previous: Float): Float {
        return previous * alpha + current * (1 - alpha)
    }

    private fun highPass(current: Float, gravity: Float): Float {
        return current - gravity
    }

    override fun onSensorChanged(event: SensorEvent?) {

        if (event?.sensor?.type == Sensor.TYPE_ACCELEROMETER) {

            val x = event.values[0]
            val y = event.values[1]
            val z = event.values[2]

            gravity[0] = lowPass(x, gravity[0])
            gravity[1] = lowPass(y, gravity[1])
            gravity[2] = lowPass(z, gravity[2])

            acceleration[0] = highPass(x, gravity[0])
            acceleration[1] = highPass(y, gravity[1])
            acceleration[2] = highPass(z, gravity[2])

            rawX.text = String.format("%.2f", x)
            rawY.text = String.format("%.2f", y)
            rawZ.text = String.format("%.2f", z)

            lowX.text = String.format("%.2f", gravity[0])
            lowY.text = String.format("%.2f", gravity[1])
            lowZ.text = String.format("%.2f", gravity[2])

            highX.text = String.format("%.2f", acceleration[0])
            highY.text = String.format("%.2f", acceleration[1])
            highZ.text = String.format("%.2f", acceleration[2])
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
    }
}

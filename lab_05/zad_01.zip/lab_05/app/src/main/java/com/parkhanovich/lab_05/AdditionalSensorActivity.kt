
package com.parkhanovich.lab_05

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class AdditionalSensorActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var gyroscope: Sensor? = null

    private lateinit var gyroX: TextView
    private lateinit var gyroY: TextView
    private lateinit var gyroZ: TextView
    private lateinit var sensorStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_additional_sensor)

        gyroX = findViewById(R.id.gyroX)
        gyroY = findViewById(R.id.gyroY)
        gyroZ = findViewById(R.id.gyroZ)
        sensorStatus = findViewById(R.id.sensorStatus)

        sensorManager =
            getSystemService(Context.SENSOR_SERVICE) as SensorManager

        gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

        if (gyroscope == null) {
            sensorStatus.text = "Gyroscope is not available"
        } else {
            sensorStatus.text = "Gyroscope is ready"
        }
    }

    override fun onResume() {
        super.onResume()

        gyroscope?.let {
            sensorManager.registerListener(
                this,
                it,
                SensorManager.SENSOR_DELAY_UI
            )
        }
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type == Sensor.TYPE_GYROSCOPE) {

            gyroX.text = String.format("X: %.3f rad/s", event.values[0])
            gyroY.text = String.format("Y: %.3f rad/s", event.values[1])
            gyroZ.text = String.format("Z: %.3f rad/s", event.values[2])

            sensorStatus.text = "Gyroscope is active"
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
    }
}

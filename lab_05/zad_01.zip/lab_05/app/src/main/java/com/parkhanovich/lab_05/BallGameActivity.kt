
package com.parkhanovich.lab_05

import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.abs

class BallGameActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private lateinit var ballView: CustomDrawableView

    private var xPosition = 0f
    private var yPosition = 0f

    private var xVelocity = 0f
    private var yVelocity = 0f

    private var lastUpdateTime = 0L
    private var initialized = false

    private val sensitivity = 180f
    private val friction = 0.97f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

        ballView = CustomDrawableView(this)
        setContentView(ballView)

        sensorManager =
            getSystemService(Context.SENSOR_SERVICE) as SensorManager

        accelerometer =
            sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        if (accelerometer == null) {
            finish()
        }
    }

    override fun onResume() {
        super.onResume()

        accelerometer?.let {
            sensorManager.registerListener(
                this,
                it,
                SensorManager.SENSOR_DELAY_GAME
            )
        }

        lastUpdateTime = 0L
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {

        if (event?.sensor?.type != Sensor.TYPE_ACCELEROMETER) return
        if (!initialized) return

        val currentTime = event.timestamp

        if (lastUpdateTime == 0L) {
            lastUpdateTime = currentTime
            return
        }

        val deltaTime = (
                (currentTime - lastUpdateTime) / 1_000_000_000f
                ).coerceIn(0f, 0.05f)

        lastUpdateTime = currentTime

        var xAcceleration = event.values[0]
        var yAcceleration = event.values[1]

        if (abs(xAcceleration) < 0.15f) xAcceleration = 0f
        if (abs(yAcceleration) < 0.15f) yAcceleration = 0f

        updateBall(xAcceleration, yAcceleration, deltaTime)
    }

    private fun updateBall(
        xAcceleration: Float,
        yAcceleration: Float,
        deltaTime: Float
    ) {

        // Horizontal acceleration
        xVelocity -= xAcceleration * sensitivity * deltaTime

        // Vertical acceleration: correct gravity direction
        yVelocity += yAcceleration * sensitivity * deltaTime

        // Apply friction
        val damping = Math.pow(
            friction.toDouble(),
            (deltaTime * 60f).toDouble()
        ).toFloat()

        xVelocity *= damping
        yVelocity *= damping

        // Update position
        xPosition += xVelocity * deltaTime
        yPosition += yVelocity * deltaTime

        val maxX = (ballView.width - ballView.ballSize)
            .coerceAtLeast(0).toFloat()

        val maxY = (ballView.height - ballView.ballSize)
            .coerceAtLeast(0).toFloat()

        // Horizontal boundaries
        if (xPosition < 0f) {
            xPosition = 0f
            xVelocity = 0f
        } else if (xPosition > maxX) {
            xPosition = maxX
            xVelocity = 0f
        }

        // Vertical boundaries
        if (yPosition < 0f) {
            yPosition = 0f
            yVelocity = 0f
        } else if (yPosition > maxY) {
            yPosition = maxY
            yVelocity = 0f
        }

        ballView.updatePosition(xPosition, yPosition)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
    }

    private inner class CustomDrawableView(context: Context) : View(context) {

        private val bitmap: Bitmap
        val ballSize = 50

        private var ballX = 0f
        private var ballY = 0f

        init {
            val originalBitmap = BitmapFactory.decodeResource(
                resources,
                R.drawable.ball
            )

            bitmap = Bitmap.createScaledBitmap(
                originalBitmap,
                ballSize,
                ballSize,
                true
            )

            setBackgroundColor(Color.WHITE)
        }

        override fun onSizeChanged(
            w: Int,
            h: Int,
            oldw: Int,
            oldh: Int
        ) {
            super.onSizeChanged(w, h, oldw, oldh)

            ballX = (w - ballSize).coerceAtLeast(0) / 2f
            ballY = (h - ballSize).coerceAtLeast(0) / 2f

            xPosition = ballX
            yPosition = ballY

            initialized = true
        }

        fun updatePosition(x: Float, y: Float) {
            ballX = x
            ballY = y
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawBitmap(bitmap, ballX, ballY, null)
        }
    }
}

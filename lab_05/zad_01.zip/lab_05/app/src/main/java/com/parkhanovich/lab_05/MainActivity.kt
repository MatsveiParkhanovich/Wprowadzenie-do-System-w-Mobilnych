
package com.parkhanovich.lab_05

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnAccelerometer).setOnClickListener {
            startActivity(Intent(this, AccelerometerActivity::class.java))
        }

        findViewById<Button>(R.id.btnLightmeter).setOnClickListener {
            startActivity(Intent(this, LightmeterActivity::class.java))
        }

        findViewById<Button>(R.id.btnSensors).setOnClickListener {
            startActivity(Intent(this, SensorsActivity::class.java))
        }

        findViewById<Button>(R.id.btnExtraSensor).setOnClickListener {
            startActivity(Intent(this, AdditionalSensorActivity::class.java))
        }

        findViewById<Button>(R.id.btnBallGame).setOnClickListener {
            startActivity(Intent(this, BallGameActivity::class.java))
        }
    }
}

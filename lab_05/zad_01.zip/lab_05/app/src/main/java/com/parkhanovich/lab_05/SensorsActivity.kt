
package com.parkhanovich.lab_05

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SensorsActivity : AppCompatActivity() {

    private lateinit var sensorManager: SensorManager
    private lateinit var sensorContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sensors)

        sensorContainer = findViewById(R.id.sensorContainer)

        sensorManager =
            getSystemService(Context.SENSOR_SERVICE) as SensorManager

        displaySensors()
    }

    private fun displaySensors() {

        val sensors = sensorManager.getSensorList(Sensor.TYPE_ALL)

        if (sensors.isEmpty()) {
            addText("No sensors available")
            return
        }

        for (sensor in sensors) {

            val sensorInfo = """
                ${sensor.name}
                
                Type: ${sensor.stringType}
                Vendor: ${sensor.vendor}
                Power: ${sensor.power} mA
                Resolution: ${sensor.resolution}
                Maximum Range: ${sensor.maximumRange}
            """.trimIndent()

            addSensorCard(sensorInfo)
        }
    }

    private fun addSensorCard(info: String) {

        val card = TextView(this).apply {
            text = info
            textSize = 15f
            setTextColor(android.graphics.Color.DKGRAY)
            setPadding(24, 20, 24, 20)
            setBackgroundColor(
                android.graphics.Color.rgb(240, 240, 245)
            )
        }

        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )

        params.setMargins(0, 0, 0, 16)

        sensorContainer.addView(card, params)
    }

    private fun addText(message: String) {
        val textView = TextView(this).apply {
            text = message
            textSize = 18f
            gravity = Gravity.CENTER
        }

        sensorContainer.addView(textView)
    }
}
